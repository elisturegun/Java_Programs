import java.util.Scanner;

/**
 * Test class for monte carlo simulation
 * @author Oyku Elis Turegun 21902976
 * @version 12.10.2021
 */

public class MonteCarloSimulator {

    public static void main( String [] args) {

        //properties
        Scanner scan = new Scanner(System.in);
        Rectangle rec;
        Circle circle;
        Point ranPoint;
        int input;
        int hits = 0;

        System.out.print("Enter the number of tries: ");
        input = scan.nextInt();

        rec = new Rectangle(0,0, 100,100);
        circle = new Circle(50,50,50);
        int tries;

        for(  tries = 0; tries <input; tries++) {

            ranPoint = rec.getRandomPoint();
            if (circle.contains(ranPoint)) {
                hits++;
            }

        }
        System.out.println("Estimate for pi: " + 4.0 * hits/tries);
        scan.close();
    }
}



