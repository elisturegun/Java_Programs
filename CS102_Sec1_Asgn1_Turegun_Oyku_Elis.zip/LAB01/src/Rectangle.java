import java.util.*;
/**
 * Rectangle class
 * @author Oyku ELis Turegun 21902976
 * @version 07.10.2021
 */
public class Rectangle {

    //properties
    Point corner;
    private double width;
    private double height;

    //constructors
    public Rectangle( double x, double y, double width,  double height){
        this.width = width;
        this.height = height;
        corner = new Point(x,y);
    }

    //methods

    /**
     * setter  method for width
     * @param width
     */
    public void setWidth(double width){
        this.width = width;
    }

    /**
     * getter method for width
     * @return width
     */
    public double getWidth(){
        return width;
    }

    /**
     * getter method for the corner point
     * @return Point corner
     */
    public Point getCorner(){
        return corner;
    }

    /**
     * setter method for the corner point
     * @param p
     */
    public void setCorner( Point p ){
        corner = p;
    }

    /**
     * getter methold for height
     * @return height
     */
    public double getHeight(){
        return height;
    }

    /**
     * setter method for height
     * @param height
     */
    public void setHeight(double height){
        this.height = height;
    }

    /**
     * checks if the given point is in the rectangle area or not
     * @param point
     * @return true if yes
     */
    public boolean contains( Point point){
        if( point.getX() >= corner.getX() && point.getX() <= (corner.getX() + getWidth()) && point.getY() >= corner.getY() && point.getY() <= (corner.getY() + getHeight())){
            return true;
        }
        else
            return false;
    }

    /**
     * method for generating random point on the rectangle area
     * @return new point
     */
    public Point getRandomPoint(){
        Random r = new Random();

        double newX = corner.getX() + getWidth() * r.nextDouble();
        double newY = corner.getY() + getHeight() * r.nextDouble();
        return new Point(newX, newY);
    }

    /**
     * String representation of the circle
     * @return circle information
     */
    public String toString(){
        return getClass() + ": width = " + getWidth() + " height = " + getHeight() + " corner = " + corner.toString();
    }
}
