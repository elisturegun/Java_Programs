/**
 * Simple java class for 2D objects
 * @author Oyku ELis Turegun 21902976
 * @version 07.10.2021
 */
public class Point {

    //properties
    private double x;
    private double y;


    //constructors
    public Point( double x, double y){
        this.x = x;
        this.y = y;
    }

    //methods

    /**
     * getter method for x coordinate
     * @return
     */
    public double getX(){
        return x;
    }

    /**
     * setter method for x coordinate
     * @param  x
     */
    public void setX( double x){
        this.x = x;
    }

    /**
     * setter method for y coordinate
     * @param y
     */
    public void setY( double y){
        this.y = y;
    }

    /**
     * getter method for y coordinate
     * @return y
     */
    public double getY(){
        return y;
    }

    /**
     * string representation of the point
     * @return x and y coordinates
     */

    public String toString(){
        return "x : " + getX() + " y : " + getY();
    }

}
