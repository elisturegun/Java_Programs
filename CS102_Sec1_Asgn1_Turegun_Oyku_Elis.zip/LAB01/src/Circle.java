/**
 * Circle class
 * @author Oyku ELis Turegun 21902976
 * @version 07.10.2021
 */
public class Circle {

    //properties
    Point center;
    private double radius;

    //constructors
    public Circle(double x, double y, double radius ){
        center = new Point(x,y);
        this.radius = radius;
    }

    //methods

    /**
     * setter method for radius
     * @param newRadius
     */
    public void setRadius( double newRadius){
        radius = newRadius;
    }

    /**
     * getter method for radius
     * @return radius
     */
    public double getRadius(){
        return radius;
    }

    /**
     * getter method for center point
     * @return center
     */
    public Point getCenter(){
        return center;
    }

    /**
     * setter method for center point
     * @param p
     */
    public void setCenter( Point p ){
        center = p;
    }

    /**
     * checks if the given point is on the circle area or not
     * @param point
     * @return true if yes
     */
    public boolean contains(Point point){
        if( (point.getX() - center.getX()) * (point.getX() - center.getX()) +
                (point.getY()- center.getY()) * (point.getY() - center.getY()) <= getRadius() * getRadius()){
            return true;
        }
        else
            return false;
    }

    /**
     * string representation for the circle
     * @return circle information
     */
    public String toString() {
        return getClass() + " : radius = " + getRadius() + " center = " + center.toString();
    }


}
